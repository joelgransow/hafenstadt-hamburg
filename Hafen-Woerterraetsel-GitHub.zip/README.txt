HAFEN-WÖRTERRÄTSEL FÜR GITHUB PAGES

Enthaltene Dateien:
- index.html
- erik-hafenarbeiter.png

Veröffentlichung:
1. Erstelle auf GitHub ein neues öffentliches Repository.
2. Lade beide Dateien in die oberste Ebene des Repositorys.
3. Öffne Settings > Pages.
4. Wähle unter "Build and deployment" die Quelle "Deploy from a branch".
5. Wähle den Branch "main" und den Ordner "/ (root)".
6. Nach der Veröffentlichung erscheint dort der Link zur Website.

Wichtig:
Die HTML- und die PNG-Datei müssen im selben Ordner liegen.
